import { getFirestore, doc, getDoc, setDoc, deleteDoc, onSnapshot} from "https://www.gstatic.com/firebasejs/9.4.0/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.4.0/firebase-app.js";
import { GoogleAuthProvider, getAuth } from "https://www.gstatic.com/firebasejs/9.4.0/firebase-auth.js";
import { firebaseConfig } from '/js/config.js';

const app = initializeApp(firebaseConfig);
const provider = new GoogleAuthProvider();
const auth = getAuth(app);
const db = getFirestore(app); 
auth.languageCode = 'en'; 

// Keep the existing "Create Game" button functionality as is
document.getElementById("createGameBtn").addEventListener("click", async function() {
  // Redirect to create game page (replace "#" with actual URL)
  const id = (Math.floor(Math.random() * 900000) + 100000).toString(); // Convert to string
  const newDocRef = doc(db, "sessions", id); 
  const setResult = await setDoc(newDocRef, {
    playerCount: 0,
  });
  
  window.location.href = "game.html?id=" + id;
  
});

// Modify the "Join Game" button functionality
document.getElementById("joinGameBtn").addEventListener("click", function() {
  // Create a prompt for the user to enter a 6 character numerical session code
  const sessionCode = prompt("Please enter the 6 character session code:");

  // Validate the input to ensure it's 6 characters and numerical
  if(sessionCode && sessionCode.length === 6 && !isNaN(sessionCode)) {
    
    // Redirect to github.html
    window.location.href = "game.html?id=" + sessionCode;
  } else {
    // If input is invalid, alert the user and don't redirect
    alert("Invalid session code. Please enter a 6 character numerical code.");
  }
});
