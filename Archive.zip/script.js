import { getFirestore, doc, getDoc, setDoc, deleteDoc, onSnapshot} from "https://www.gstatic.com/firebasejs/9.4.0/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.4.0/firebase-app.js";
import { GoogleAuthProvider, getAuth } from "https://www.gstatic.com/firebasejs/9.4.0/firebase-auth.js";
import { firebaseConfig } from '/js/config.js';

const app = initializeApp(firebaseConfig);
const provider = new GoogleAuthProvider();
const auth = getAuth(app);
const db = getFirestore(app); 
auth.languageCode = 'en'; 

const id = new URLSearchParams(window.location.search).get('id');
const ref = doc(db, "sessions", id);
let playerCount = 0;
const buttons = document.querySelectorAll("#goBoard .slot button");
buttons.forEach(button => button.disabled = true);
let firstPlayer = false;
let firstPlayerTurn = true;
let lever = false;
let count = 0;
let secondCount = 0;
const sessionInfo = document.getElementById('sessionCode');
sessionInfo.textContent = "Join Code: " + id;
const endGameButton = document.getElementById('endGameButton');
const endGamePopup = document.getElementById('endGamePopup');
const closeButton = document.querySelector('.close');
const winnerSpan = document.getElementById('winner');
const totalMovesSpan = document.getElementById('totalMoves');

async function gameExists(){
  const docSnapshot = await getDoc(doc(db, "sessions", id));
  if(docSnapshot.exists()){
    return true;
  } else {
    return false;
  }
}
incrementPlayerCount();

onSnapshot(ref, async (snapshot) => {
  if(playerCount<2){
    if (snapshot.exists()) {
        const docSnapshot = await getDoc(doc(db, "sessions", id));
        playerCount = docSnapshot.data().playerCount;
        initializeGame(); // This will update the game based on the latest data
    } else {
        console.log("No such document!");
    }
  }
});


function initializeGame(){
  gameExists().then((exists) => {
    if(exists && playerCount >= 2) {
      const playerInfoElement = document.getElementById('playerInfo');
      playerInfoElement.textContent = "Players: 2/2";
      document.getElementById('turnInfo').textContent = "Black's Turn";
      const boardSize = 21;
      let board = createBoardArray(boardSize); // Made this `let` to allow updates
      const boardElement = document.getElementById('goBoard');
      let isBlack = !firstPlayer;
      let duplicate = false;    
      let cornerCount = 0;
      let sameCount = 0;
      let previousBoard = null;  
      let placeCount = 0;  
      
      onSnapshot(ref, async (doc) => {
        if(!isBlack && count === 0){
          disable();
        }
        const data = doc.data();
        if (data && data.board) {
            board = convert(data.board, boardSize);
            renderBoard(board, boardElement);
            if(firstPlayer){
              disable();
            }
            if(count === 0){
              disable();  
              firstPlayer=!firstPlayer;
            }
            firstPlayer=!firstPlayer;
            if(!isBlack && count%2===0){
              firstPlayer=!firstPlayer;
            }
            count++;
            updateTurnDisplay();
        }
        if(data.playerCount !== 2 && playerCount === 2){
          alert("Opponent has Left!");
          window.location.href = 'index.html';
        }
      });
      renderBoard(board, boardElement);
      
      function updateTurnDisplay() {
        const turnInfoElement = document.getElementById('turnInfo');
        if (playerCount < 2) {
          turnInfoElement.textContent = 'Waiting for another player...';
        } else {
          if(isBlack && firstPlayer){
            turnInfoElement.textContent = "Black's Turn";
          }
          else if(isBlack && !firstPlayer){
            turnInfoElement.textContent = "White's Turn";
          }
          else if(!isBlack && !firstPlayer){
            turnInfoElement.textContent = "Black's Turn";
          }
          else if(!isBlack && firstPlayer){
            turnInfoElement.textContent = "White's Turn";
          }
          const counts = countWhite(board);
          blackLive.textContent = counts[1];
          whiteLive.textContent = counts[0];
        }
      }  

      function createBoardArray(size) {
        let board = [];
        for (let i = 0; i < size; i++) {
          board.push(new Array(size).fill(0));
        }
        for (let i = 0; i < size - 1; i++) {
          board[0][i] = 3;
          board[i][0] = 3;
          board[size - 1][i] = 3;
          board[i][size - 1] = 3;
        }
        return board;
      }

      function renderBoard(board, element) {
        element.innerHTML = ''; // Clear previous state
        board.forEach((row, rowIndex) => {
          row.forEach((cell, colIndex) => {
            let cellElement = document.createElement('div');
            cellElement.className = 'slot';
            let button = document.createElement('button');
            button.onclick = () => placeStone(rowIndex, colIndex);

            if((cell === 0 || cell === 10 || cell === 20) && !firstPlayer){
              button.onmouseover = () => {
                  button.classList.add(isBlack ? 'hover-black' : 'hover-white');
              };
              button.onmouseout = () => {
                  button.classList.remove('hover-black', 'hover-white');
              };
            }
            cellElement.appendChild(button);

            if (cell === 1) {
              let stone = document.createElement('div');
              stone.className = 'stone white';
              button.appendChild(stone);
            } else if (cell === 2) {
              let stone = document.createElement('div');
              stone.className = 'stone black';
              button.appendChild(stone);
            }
            element.appendChild(cellElement);
          });
        });
      }

      function areBoardsEqual(board1, board2) {
          if (!board1 || !board2) return false; // Ensure both boards are not null
          if (board1.length !== board2.length) return false;
          for (let i = 0; i < board1.length; i++) {
              for (let j = 0; j < board1[i].length; j++) {
                  if (board1[i][j] !== board2[i][j]) return false;
              }
          }
          return true;
      }

      async function placeStone(row, col) {
          if (board[row][col] === 0 || board[row][col] === 10 || board[row][col] === 20) {
              let tempBoard = board.map(row => [...row]);
              tempBoard[row][col] = isBlack ? 2 : 1;
              let capturedStones = checkAndRemoveSurroundedStones(tempBoard, isBlack);
              let visited = new Set(), group = [], emptyTiles = new Set();
              let isSelfCapture = isSurrounded(tempBoard, row, col, tempBoard[row][col], visited, group, emptyTiles) && capturedStones === 0;
              if (isSelfCapture || areBoardsEqual(tempBoard, previousBoard)) {
                  alert("No Duplicate Moves!");
                  return;
              }
              board = tempBoard;
              previousBoard = board.map(row => [...row]);
            
              const flattenedBoard = board.flat();
              try {
                  await setDoc(doc(db, "sessions", id), {
                      board: flattenedBoard,
                      firstPlayer: firstPlayer,
                      win: false,
                  }, { merge: true });
              } catch (error) {
                  console.error("Error updating document: ", error);
              }
          }
      }

      function checkAndRemoveSurroundedStones(board, isBlack) {
        let oppositeColor = isBlack ? 1 : 2;
        // Iterate through the entire board
        board.forEach((row, rowIndex) => {
          row.forEach((cell, colIndex) => {
            if (cell === oppositeColor) { // Check each stone of the opposite color
              let visited = new Set();
              let emptyTiles = new Set();
              let group = [];
              if (isSurrounded(board, rowIndex, colIndex, oppositeColor, visited, group, emptyTiles)) {
                group.forEach(([r, c]) => {
                  if(isBlack){
                    board[r][c] = 10
                  }
                  else{
                    board[r][c] = 20
                  }
                });
              }
            }
          });
        });
      }

      function isSurrounded(board, row, col, color, visited, group, emptyTiles) {
        if(board[row][col] === 3){
          cornerCount++;
        }
        if(board[row][col] === 1 || board[row][col] === 2){
          sameCount++;
        }
        if(cornerCount >= 37 || sameCount >= 125){
          sameCount = 0;
          cornerCount = 0;
          return false;
        } 
        
        
        let key = row + "," + col;
        if (visited.has(key)){
          return true; 
        }
        visited.add(key);
        if (!isValidPos(row, col)){
          return false;
        }   
        if (board[row][col] === 0 || board[row][col] === 10 || board[row][col] === 20) {
          emptyTiles.add(key);
        } else if (board[row][col] !== color) {
          return true;
        } else {
          group.push([row, col]);
        }

        const directions = [[-1, 0], [0, 1], [1, 0], [0, -1]];
        return directions.every(([dRow, dCol]) => {
          return isSurrounded(board, row + dRow, col + dCol, color, visited, group, emptyTiles);
        });
      }

      function isValidPos(row, col) {
        return row >= 0 && col >= 0 && row < boardSize && col < boardSize;
      }
    }
  });
}

window.addEventListener('beforeunload', async function(event) {
  if(playerCount === 2){
    const playerInfoElement = document.getElementById('playerInfo');
    playerInfoElement.textContent = "Players: 1/2";
  }
  const ref = doc(db, "sessions", id);
  setDoc(ref, { playerCount: playerCount - 1 }, { merge: true });
  playerCount = playerCount - 1;
  if(playerCount <= 1) {
    try {
      await deleteDoc(doc(db, "sessions", id));
    } catch(error) {
      console.error("Error deleting document:", error);
    }
  }
});


window.addEventListener('DOMContentLoaded', async function() {
  const docSnapshot = await getDoc(doc(db, "sessions", id));
  const tempPlayerCount = docSnapshot.data().playerCount;
  if (tempPlayerCount >= 2) {
    alert("This Game is Full!");
    window.location.href = 'index.html';
  }
})  

endGameButton.addEventListener('click', async () => {
  const ref = doc(db, "sessions", id);
  setDoc(ref, { win: true }, { merge: true });
  const docSnapshot = await getDoc(doc(db, "sessions", id));
  win(convert(docSnapshot.data().board, 19));
});

function countWhite(board) {
  let whiteCount = 0;
  let blackCount = 0;
  board.forEach(row => {row.forEach(cell => {
    if (cell === 2 || cell === 10) {
      whiteCount++;
    }
    if (cell === 1 || cell === 20){
      blackCount++;
    }
  });});
  return [blackCount, whiteCount];
}

const snap = await getDoc(doc(db, "sessions", id));
onSnapshot(ref, async (snap) => {
  if (snap.data().win === true) {
    win(convert(snap.data().board, 19));
  }
});

function win(board){
  endGamePopup.style.display = 'block';
  const counts = countWhite(board);
  blackTerritory.textContent = counts[1];
  whiteTerritory.textContent = counts[0];
  if(counts[1] > counts[0]){
    winnerSpan.textContent = "Black";
  }
  else if(counts[1] < counts[0]){
    winnerSpan.textContent = "White";
  }
  else if(counts[1] === counts[0]){
    winnerSpan.textContent = "Tie";
  }
}

function convert(flatArray, size) {
  let board = [];
  for (let i = 0; i < size; i++) {
    board.push(flatArray.slice(i * size, (i + 1) * size));
  }
  return board;
} 

function disable(){
  document.querySelectorAll("#goBoard .slot button").forEach(button => button.disabled = true);
}

async function incrementPlayerCount() {
  const snapshot = await getDoc(doc(db, "sessions", id));
  playerCount = snapshot.data().playerCount;
  if(playerCount === 1){
    firstPlayer = true;
  }
  if(playerCount === 2){
    firstPlayer = false;
  }
  const ref = doc(db, "sessions", id);
  setDoc(ref, { playerCount: playerCount + 1 }, { merge: true });
}

const redirectButton = document.getElementById('redirectButton');
redirectButton.addEventListener('click', () => {
  window.location.href = 'index.html';
});
closeButton.addEventListener('click', () => {
  endGamePopup.style.display = 'none';
});
