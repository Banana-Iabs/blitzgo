export const firebaseConfig = {
  apiKey: "AIzaSyDgaADWH-26fyQ7oypFl4i4LRKTvBOqxM0",
  authDomain: "blitz-3d9f3.firebaseapp.com",
  projectId: "blitz-3d9f3",
  storageBucket: "blitz-3d9f3.appspot.com",
  messagingSenderId: "750432527279",
  appId: "1:750432527279:web:5c1a6ce642d1b65a70c55a",
  measurementId: "G-WFP5TSC6E9"
};
